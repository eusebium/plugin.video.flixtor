# plugin.video.flixtor

## Partialy Working :D ##

[![Donate](https://img.shields.io/badge/Donate-Paypal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=83UA43TPBRHLL)

## What it is ##

Flixtor.se unofficial Python scraper for KODI.

Watch Movies and TV Shows. Currently only free stuff available, I am not a VIP User, if anyone wants to donate for VIP membership Donate via PayPal and I will try to implement VIP Login.

## Why ##

To learn new things

## [Changelog](https://github.com/markop159/plugin.video.planettv/blob/master/changelog.txt) ##
